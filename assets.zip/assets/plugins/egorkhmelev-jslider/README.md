# jQuery Slider plugin

jQuery Slider is easy to use and multifunctional jQuery plugin.

[Check out demos and documentations here](http://egorkhmelev.github.com/jslider/)

## Bugs / Pull requests

THIS PROJECT IS NOT MAINTAINED ANYMORE. You are free to fork it and start a new project.
I will add the best forks here.

## License

(MIT License) — Copyright &copy; 2012 Egor Khmelev
